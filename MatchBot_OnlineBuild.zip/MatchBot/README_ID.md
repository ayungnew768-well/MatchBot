# MatchBot 1.0

Bot Android untuk game pencocokan ubin 5 x 6 seperti screenshot yang diberikan.

## Cara kerja
- Mengambil screenshot layar menggunakan AccessibilityService Android.
- Membaca 30 posisi ubin pada grid 5 kolom x 6 baris.
- Membandingkan gambar ubin dengan template dari screenshot contoh.
- Jika menemukan 3 ubin yang sama, bot mengetuk ketiganya satu per satu.
- Jika hanya menemukan pasangan, bot mengetuk pasangan.
- Scan ulang sekitar setiap 0,9 detik.

## Penting
- Project ini dibuat untuk Android 11+ (API 30+) dan layout game yang mirip dengan screenshot contoh.
- Posisi grid menggunakan koordinat relatif berdasarkan screenshot contoh. Jika game/device berbeda skala atau posisi, perlu kalibrasi ulang.
- Bot tidak mengklik iklan dan tidak menekan tombol X iklan otomatis. Pengguna tetap mengendalikan iklan sendiri.
- Game harus berada di depan saat bot dijalankan.

## Menjalankan
1. Buka project di Android Studio.
2. Build/install ke HP Android.
3. Buka MatchBot.
4. Tekan AKTIFKAN AKSESIBILITAS dan aktifkan MatchBot.
5. Kembali ke game.
6. Buka MatchBot lagi bila perlu, tekan MULAI BOT, lalu kembali ke game.
7. Untuk berhenti, buka MatchBot dan tekan HENTIKAN BOT.

## Batasan build
Folder ini adalah project Android Studio lengkap beserta template gambar. APK siap-install tidak dapat saya kompilasi di lingkungan percakapan ini karena Android SDK/build tools tidak tersedia. Setelah dibuka di Android Studio, pilih Build > Build APK(s).
