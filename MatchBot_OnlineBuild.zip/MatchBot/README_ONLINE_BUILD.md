# MatchBot — Build APK Online

Project ini sudah dilengkapi GitHub Actions. Tujuannya supaya APK dapat dibuat di server GitHub tanpa Android Studio di HP.

## Cara paling mudah dari HP
1. Buat repository baru di GitHub.
2. Upload isi folder `MatchBot` ke repository (bukan file ZIP-nya saja).
3. Setelah selesai upload, buka tab **Actions**.
4. Pilih workflow **Build MatchBot APK**.
5. Jalankan **Run workflow** jika diperlukan.
6. Tunggu sampai status hijau.
7. Buka hasil run tersebut → bagian **Artifacts** → download `MatchBot-APK`.
8. Ekstrak ZIP artifact dan install `app-debug.apk` di HP.

Workflow memakai Gradle 8.7 + Java 17 dan membangun `app-debug.apk`.

## Fungsi bot
- membaca papan 5 x 6 seperti screenshot yang diberikan;
- mencari kelompok ubin yang tampak sama;
- mengetuk hingga 3 ubin per siklus;
- membaca papan lagi setelah berubah;
- tidak menekan iklan dan tidak menutup iklan otomatis.

## Catatan
Versi ini ditargetkan untuk layout game yang mirip screenshot referensi. Jika game mengubah ukuran/posisi papan secara signifikan, koordinat dan pengenalan gambar mungkin perlu disesuaikan.
