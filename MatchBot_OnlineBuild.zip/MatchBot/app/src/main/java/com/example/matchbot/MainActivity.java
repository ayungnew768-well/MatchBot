package com.example.matchbot;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40,50,40,40);
        TextView title = new TextView(this); title.setText("MatchBot\n\nBot pencocok ubin otomatis"); title.setTextSize(24); title.setTextColor(Color.DKGRAY);
        TextView info = new TextView(this); info.setText("\n1. Aktifkan layanan aksesibilitas MatchBot.\n2. Kembali ke game.\n3. Tekan MULAI BOT.\n4. Bot akan mencari 3 ubin yang sama lalu mengetuknya.\n\nBot ini tidak menekan atau menonton iklan otomatis."); info.setTextSize(16);
        Button access = new Button(this); access.setText("AKTIFKAN AKSESIBILITAS");
        Button start = new Button(this); start.setText("MULAI BOT");
        Button stop = new Button(this); stop.setText("HENTIKAN BOT");
        box.addView(title); box.addView(info); box.addView(access); box.addView(start); box.addView(stop); setContentView(box);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        start.setOnClickListener(v -> getSharedPreferences("bot",0).edit().putBoolean("running",true).apply());
        stop.setOnClickListener(v -> getSharedPreferences("bot",0).edit().putBoolean("running",false).apply());
    }
}
