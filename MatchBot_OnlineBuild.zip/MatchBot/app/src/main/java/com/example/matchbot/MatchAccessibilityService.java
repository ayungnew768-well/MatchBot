package com.example.matchbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Path;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

public class MatchAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Executor mainExecutor = Runnable::run;
    private boolean busy = false;
    private final String[] names = {"green","pink","brown","orange","purple","white","bowl","sushi","coin"};
    private Bitmap[] templates;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        templates = new Bitmap[names.length];
        for (int i=0;i<names.length;i++) {
            try (InputStream in = getAssets().open("templates/"+names[i]+".png")) {
                templates[i] = android.graphics.BitmapFactory.decodeStream(in);
            } catch (IOException ignored) {}
        }
        schedule();
    }

    private void schedule() {
        handler.postDelayed(() -> {
            if (isRunning() && !busy) take();
            schedule();
        }, 900);
    }
    private boolean isRunning() { return getSharedPreferences("bot",0).getBoolean("running",false); }

    private void take() {
        busy = true;
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult result) {
                HardwareBuffer hb = result.getHardwareBuffer();
                Bitmap hw = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
                Bitmap shot = hw == null ? null : hw.copy(Bitmap.Config.ARGB_8888, false);
                if (hw != null) hw.recycle();
                hb.close();
                if (shot != null) {
                    try { findAndTap(shot); } finally { shot.recycle(); }
                }
                busy = false;
            }
            @Override public void onFailure(int errorCode) { busy = false; }
        });
    }

    private void findAndTap(Bitmap shot) {
        int w=shot.getWidth(), h=shot.getHeight();
        // Normalized grid positions based on the supplied 5 x 6 board screenshot.
        float[] xs={0.267f,0.386f,0.505f,0.625f,0.745f};
        float[] ys={0.196f,0.262f,0.327f,0.393f,0.459f,0.525f};
        Map<Integer,List<float[]>> groups = new HashMap<>();
        for(int r=0;r<6;r++) for(int c=0;c<5;c++) {
            int x=Math.round(w*xs[c]), y=Math.round(h*ys[r]);
            int best=-1; float score=999f;
            for(int t=0;t<templates.length;t++) {
                if(templates[t]==null) continue;
                float s=compare(shot,x,y,templates[t]);
                if(s<score){score=s;best=t;}
            }
            // Low score = visually close to a known tile. Empty/background cells are rejected.
            if(best>=0 && score<0.115f) groups.computeIfAbsent(best,k->new ArrayList<>()).add(new float[]{x,y});
        }
        // Prefer a complete triple, then a pair. Only one group is tapped per scan so the next scan sees the new board.
        List<float[]> chosen=null;
        for(List<float[]> g:groups.values()) if(g.size()>=3){chosen=g;break;}
        if(chosen==null) for(List<float[]> g:groups.values()) if(g.size()>=2){chosen=g;break;}
        if(chosen==null) return;
        int n=Math.min(3,chosen.size());
        for(int i=0;i<n;i++) tap(chosen.get(i)[0],chosen.get(i)[1],i*180);
    }

    private float compare(Bitmap shot,int cx,int cy,Bitmap tpl){
        int size=56; int half=size/2; float sum=0; int count=0;
        for(int j=0;j<size;j+=2) for(int i=0;i<size;i+=2){
            int sx=cx-half+i, sy=cy-half+j;
            if(sx<0||sy<0||sx>=shot.getWidth()||sy>=shot.getHeight()) continue;
            int tx=(int)((i/(float)size)*tpl.getWidth()), ty=(int)((j/(float)size)*tpl.getHeight());
            int a=shot.getPixel(sx,sy), b=tpl.getPixel(Math.min(tx,tpl.getWidth()-1),Math.min(ty,tpl.getHeight()-1));
            float dr=Math.abs(Color.red(a)-Color.red(b))/255f;
            float dg=Math.abs(Color.green(a)-Color.green(b))/255f;
            float db=Math.abs(Color.blue(a)-Color.blue(b))/255f;
            sum+=(dr+dg+db)/3f; count++;
        }
        return count==0?999f:sum/count;
    }

    private void tap(float x,float y,long delay){
        handler.postDelayed(() -> {
            Path p=new Path(); p.moveTo(x,y);
            GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,55);
            dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),null,null);
        },delay);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() { busy=false; }
}
